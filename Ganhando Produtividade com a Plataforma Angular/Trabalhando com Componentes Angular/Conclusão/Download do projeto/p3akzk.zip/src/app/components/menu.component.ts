import { Component } from '@angular/core';

@Component({
  selector: 'menu-component',
  template: '<h2>Vitor</h2>',
  styles: ['h2{ color: blue}'],
})
export class MenuComponent {}
